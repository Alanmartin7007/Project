# grant access to the network file
cd ..
chmod -R +x ./local
cd ./local

# start setup
./start.sh

