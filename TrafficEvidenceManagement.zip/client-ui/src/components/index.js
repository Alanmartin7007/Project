export {default as Navbar } from './Navbar';
export {default as Login} from "./Login";
export {default as Signup} from "./Signup";
export {default as Homepage} from "./Homepage";
export {default as AddEmployee} from "./AddEmployee";
export {default as EmployeeList} from "./EmployeeList";
export {default as AddPrivateData} from "./AddPrivateData";
export {default as ShowPrivateData} from "./ShowPrivateData";
